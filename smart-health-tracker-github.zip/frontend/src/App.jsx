import React, { useEffect, useState } from 'react'
import { Routes, Route, Link, useNavigate } from 'react-router-dom'
import Login from './components/Login'
import Dashboard from './components/Dashboard'
import Settings from './components/Settings'
import DoctorDashboard from './components/DoctorDashboard'
import { api, setToken, getToken, clearToken } from './services/api'

export default function App() {
  const [user, setUser] = useState(null)
  const navigate = useNavigate()

  useEffect(() => {
    const t = getToken()
    if (t) {
      api.get('/me').then(res => setUser(res.data)).catch(() => clearToken())
    }
  }, [])

  const logout = () => {
    clearToken()
    setUser(null)
    navigate('/login')
  }

  return (
    <div style={{maxWidth: 1100, margin: '0 auto', padding: 16, fontFamily: 'ui-sans-serif, system-ui'}}>
      <header style={{display:'flex', alignItems:'center', justifyContent:'space-between'}}>
        <h1>Smart Health Tracker (Advanced)</h1>
        <nav style={{display:'flex', gap:12}}>
          <Link to="/">Dashboard</Link>
          <Link to="/settings">Settings</Link>
          <Link to="/doctor">Doctor</Link>
          {user ? <button onClick={logout}>Logout</button> : <Link to="/login">Login</Link>}
        </nav>
      </header>
      <hr/>
      <Routes>
        <Route path="/" element={<Dashboard user={user} setUser={setUser} />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="/login" element={<Login setUser={setUser} />} />
        <Route path="/doctor" element={<DoctorDashboard user={user} />} />
      </Routes>
      <footer style={{marginTop: 24, fontSize: 12, opacity: 0.7}}>
        Built with React + Vite • Charts via Chart.js • Socket.IO for live HR
      </footer>
    </div>
  )
}