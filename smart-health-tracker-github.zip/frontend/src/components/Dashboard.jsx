import React, { useEffect, useState } from 'react'
import { api } from '../services/api'
import { Line, Bar } from 'react-chartjs-2'
import {
  Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, BarElement, Title, Tooltip, Legend,
} from 'chart.js'
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, Title, Tooltip, Legend)

export default function Dashboard({ user, setUser }) {
  const [metrics, setMetrics] = useState([])
  const [alerts, setAlerts] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const init = async () => {
      try {
        // if not logged in, auto create a demo user
        if (!user) {
          try {
            await api.post('/register', {name:'Demo User', email:'demo@example.com', password:'demo1234', role:'user'})
          } catch {}
          // login
          const res = await api.post('/login', {email:'demo@example.com', password:'demo1234'})
          localStorage.setItem('token', res.data.token)
          const me = await api.get('/me')
          setUser(me.data)
        }
        await api.post('/simulate', {days: 14})
        const m = await api.get('/metrics?days=14')
        setMetrics(m.data)
        const a = await api.get('/alerts')
        setAlerts(a.data)
      } catch (e) {
        setError('Failed to load data')
      } finally {
        setLoading(false)
      }
    }
    init()
  }, [])

  if (loading) return <p>Loading...</p>
  if (error) return <p style={{color:'red'}}>{error}</p>

  const labels = metrics.map(m => new Date(m.timestamp).toLocaleDateString())
  const hrData = {
    labels,
    datasets: [{ label: 'Heart Rate (bpm)', data: metrics.map(m=>m.heart_rate) }]
  }
  const stepsData = {
    labels,
    datasets: [{ label: 'Steps', data: metrics.map(m=>m.steps) }]
  }
  const sleepData = {
    labels,
    datasets: [{ label: 'Sleep (hrs)', data: metrics.map(m=>m.sleep_hours) }]
  }

  const cards = [
    {title: 'Avg Heart Rate', value: Math.round(metrics.reduce((s,m)=>s+m.heart_rate,0)/metrics.length)},
    {title: 'Total Steps', value: metrics.reduce((s,m)=>s+m.steps,0)},
    {title: 'Avg Sleep', value: (metrics.reduce((s,m)=>s+m.sleep_hours,0)/metrics.length).toFixed(1)},
    {title: 'Total Calories', value: Math.round(metrics.reduce((s,m)=>s+m.calories,0))},
  ]

  return (
    <div>
      <section style={{display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(180px,1fr))', gap:12}}>
        {cards.map((c,i)=>(
          <div key={i} style={{border:'1px solid #ddd', borderRadius:12, padding:12}}>
            <div style={{fontSize:12, opacity:0.7}}>{c.title}</div>
            <div style={{fontSize:24, fontWeight:600}}>{c.value}</div>
          </div>
        ))}
      </section>

      <section style={{display:'grid', gridTemplateColumns:'1fr', gap:16, marginTop:16}}>
        <div style={{border:'1px solid #eee', borderRadius:12, padding:12}}>
          <h3>Heart Rate Trend</h3>
          <Line data={hrData} />
        </div>
        <div style={{border:'1px solid #eee', borderRadius:12, padding:12}}>
          <h3>Steps per Day</h3>
          <Bar data={stepsData} />
        </div>
        <div style={{border:'1px solid #eee', borderRadius:12, padding:12}}>
          <h3>Sleep Hours</h3>
          <Line data={sleepData} />
        </div>
      </section>

      <section style={{marginTop:16}}>
        <h3>Alerts (last 24h)</h3>
        {alerts.length === 0 ? <p>No alerts 🎉</p> : (
          <ul>
            {alerts.map((a,i)=>(<li key={i}>{a.message}</li>))}
          </ul>
        )}
      </section>
    </div>
  )
}