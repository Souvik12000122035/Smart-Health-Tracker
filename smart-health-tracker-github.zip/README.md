# Smart Health Tracker (Advanced) — Roles + Doctor view + Live HR via Socket.IO

## Run locally
1. Start backend (Socket.IO server):
```bash
cd backend
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```
2. Start frontend:
```bash
cd frontend
npm install
npm run dev
```
3. Use the web UI. Register a doctor account to access the Doctor dashboard. Use `Settings` to simulate data or `Doctor` to view patients and simulate live HR.

## Notes
- Backend uses `flask-socketio` + `eventlet`. If deploying, ensure correct production server (eventlet/gevent) is used.
- Socket auth: client must emit `auth` with `{token}` after connecting.
- Doctors can join patient rooms with `join_user_room` after authenticating.