import os
import datetime as dt
import random
from functools import wraps

from flask import Flask, request, jsonify
from flask_cors import CORS
from sqlalchemy import create_engine, Column, Integer, Float, String, DateTime, ForeignKey
from sqlalchemy.orm import sessionmaker, declarative_base, relationship
from werkzeug.security import generate_password_hash, check_password_hash
import jwt

# Flask-SocketIO
from flask_socketio import SocketIO, emit, join_room, leave_room, disconnect

DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite:///health.db")
JWT_SECRET = os.environ.get("JWT_SECRET", "dev_secret_change_me")
JWT_ALGO = "HS256"

engine = create_engine(DATABASE_URL, echo=False)
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    email = Column(String, unique=True, nullable=False, index=True)
    password_hash = Column(String, nullable=False)
    role = Column(String, default="user")  # roles: user, doctor, admin
    created_at = Column(DateTime, default=dt.datetime.utcnow)

    metrics = relationship("Metric", back_populates="user", cascade="all, delete-orphan")

class Metric(Base):
    __tablename__ = "metrics"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), index=True)
    timestamp = Column(DateTime, default=dt.datetime.utcnow, index=True)
    steps = Column(Integer, default=0)
    heart_rate = Column(Integer, default=70)
    calories = Column(Float, default=0.0)
    sleep_hours = Column(Float, default=0.0)

    user = relationship("User", back_populates="metrics")

Base.metadata.create_all(engine)

app = Flask(__name__)
CORS(app)
app.config['SECRET_KEY'] = JWT_SECRET
socketio = SocketIO(app, cors_allowed_origins="*")

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        auth_header = request.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            token = auth_header.split(" ", 1)[1].strip()
        if not token:
            return jsonify({"error": "Token missing"}), 401
        try:
            data = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGO])
            user_id = data["sub"]
            role = data.get("role", "user")
        except Exception as e:
            return jsonify({"error": "Invalid token", "details": str(e)}), 401
        return f(user_id, role, *args, **kwargs)
    return decorated

def create_token(user):
    payload = {
        "sub": user.id,
        "name": user.name,
        "email": user.email,
        "role": user.role,
        "iat": int(dt.datetime.utcnow().timestamp()),
        "exp": int((dt.datetime.utcnow() + dt.timedelta(hours=12)).timestamp())
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGO)

@app.route("/api/register", methods=["POST"])
def register():
    data = request.get_json(force=True)
    name = data.get("name", "").strip()
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")
    role = data.get("role", "user")
    if not name or not email or not password:
        return jsonify({"error": "name, email, password are required"}), 400
    db = SessionLocal()
    if db.query(User).filter_by(email=email).first():
        return jsonify({"error": "email already registered"}), 400
    user = User(name=name, email=email, password_hash=generate_password_hash(password), role=role)
    db.add(user)
    db.commit()
    token = create_token(user)
    return jsonify({"token": token, "user": {"id": user.id, "name": user.name, "email": user.email, "role": user.role}})

@app.route("/api/login", methods=["POST"])
def login():
    data = request.get_json(force=True)
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")
    db = SessionLocal()
    user = db.query(User).filter_by(email=email).first()
    if not user or not check_password_hash(user.password_hash, password):
        return jsonify({"error": "invalid credentials"}), 401
    token = create_token(user)
    return jsonify({"token": token, "user": {"id": user.id, "name": user.name, "email": user.email, "role": user.role}})

@app.route("/api/me", methods=["GET"])
@token_required
def me(user_id, role):
    db = SessionLocal()
    user = db.query(User).get(user_id)
    return jsonify({"id": user.id, "name": user.name, "email": user.email, "role": user.role, "created_at": user.created_at.isoformat()})

# Doctor-only endpoint to list users (patients)
@app.route("/api/users", methods=["GET"])
@token_required
def list_users(user_id, role):
    if role != "doctor" and role != "admin":
        return jsonify({"error": "forbidden"}), 403
    db = SessionLocal()
    users = db.query(User).filter(User.role == "user").all()
    return jsonify([{"id": u.id, "name": u.name, "email": u.email, "created_at": u.created_at.isoformat()} for u in users])

@app.route("/api/users/<int:uid>/metrics", methods=["GET"])
@token_required
def user_metrics(user_id, role, uid):
    # Only doctor/admin or the user themself can view
    if role not in ("doctor", "admin") and user_id != uid:
        return jsonify({"error": "forbidden"}), 403
    db = SessionLocal()
    rows = db.query(Metric).filter(Metric.user_id == uid).order_by(Metric.timestamp.desc()).limit(200).all()
    return jsonify([{"id": r.id, "timestamp": r.timestamp.isoformat(), "steps": r.steps, "heart_rate": r.heart_rate, "calories": r.calories, "sleep_hours": r.sleep_hours} for r in rows])

@app.route("/api/metrics", methods=["GET"])
@token_required
def get_metrics(user_id, role):
    """Return last N days of metrics (default 7)."""
    db = SessionLocal()
    days = int(request.args.get("days", 7))
    since = dt.datetime.utcnow() - dt.timedelta(days=days)
    rows = (
        db.query(Metric)
        .filter(Metric.user_id == user_id, Metric.timestamp >= since)
        .order_by(Metric.timestamp.asc())
        .all()
    )
    return jsonify([{
        "id": r.id,
        "timestamp": r.timestamp.isoformat(),
        "steps": r.steps,
        "heart_rate": r.heart_rate,
        "calories": r.calories,
        "sleep_hours": r.sleep_hours,
    } for r in rows])

@app.route("/api/metrics", methods=["POST"])
@token_required
def add_metric(user_id, role):
    data = request.get_json(force=True)
    db = SessionLocal()
    m = Metric(
        user_id=user_id,
        timestamp=dt.datetime.fromisoformat(data.get("timestamp")) if data.get("timestamp") else dt.datetime.utcnow(),
        steps=int(data.get("steps", 0)),
        heart_rate=int(data.get("heart_rate", 70)),
        calories=float(data.get("calories", 0.0)),
        sleep_hours=float(data.get("sleep_hours", 0.0)),
    )
    db.add(m)
    db.commit()
    # Emit websocket event to any listeners in patient's room
    try:
        socketio.emit('hr_update', {'user_id': user_id, 'heart_rate': m.heart_rate, 'timestamp': m.timestamp.isoformat()}, room=f"user_{user_id}")
    except Exception as e:
        print("socket emit failed:", e)
    return jsonify({"status": "ok", "id": m.id})

@app.route("/api/alerts", methods=["GET"])
@token_required
def get_alerts(user_id, role):
    """Simple rule-based alerts from the last day of data."""
    db = SessionLocal()
    since = dt.datetime.utcnow() - dt.timedelta(days=1)
    rows = (
        db.query(Metric)
        .filter(Metric.user_id == user_id, Metric.timestamp >= since)
        .order_by(Metric.timestamp.desc())
        .all()
    )
    alerts = []
    for r in rows:
        if r.heart_rate > 110:
            alerts.append({"type": "HIGH_HEART_RATE", "message": f"Unusually high heart rate ({r.heart_rate} bpm) at {r.timestamp}"})
        if r.sleep_hours < 6 and r.sleep_hours > 0:
            alerts.append({"type": "LOW_SLEEP", "message": f"Low sleep recorded ({r.sleep_hours} hrs) on {r.timestamp.date()}"})
        if r.steps < 3000 and r.steps > 0:
            alerts.append({"type": "LOW_ACTIVITY", "message": f"Low steps ({r.steps}) on {r.timestamp.date()}"})
    return jsonify(alerts)

@app.route("/api/simulate", methods=["POST"])
@token_required
def simulate(user_id, role):
    """Generate synthetic wearable data for the past N days for the authenticated user."""
    data = request.get_json(force=True) if request.data else {}
    days = int(data.get("days", 7))
    db = SessionLocal()
    now = dt.datetime.utcnow().replace(hour=23, minute=0, second=0, microsecond=0)
    created = 0
    for i in range(days):
        day = now - dt.timedelta(days=i)
        steps = random.randint(1500, 12000)
        heart = random.randint(55, 140)
        calories = round(random.uniform(1200, 3200), 2)
        sleep = round(random.uniform(4.0, 9.0), 1)
        m = Metric(user_id=user_id, timestamp=day, steps=steps, heart_rate=heart, calories=calories, sleep_hours=sleep)
        db.add(m)
        created += 1
        # emit each day's hr to listeners (simulate historical push)
        try:
            socketio.emit('hr_update', {'user_id': user_id, 'heart_rate': m.heart_rate, 'timestamp': m.timestamp.isoformat()}, room=f"user_{user_id}")
        except Exception as e:
            pass
    db.commit()
    return jsonify({"status": "ok", "created": created})

@app.route("/api/emit-simulate", methods=["POST"])
@token_required
def emit_simulate(user_id, role):
    """Endpoint only for doctors/admins to simulate live HR for a patient id (for demo)."""
    if role not in ("doctor", "admin"):
        return jsonify({"error": "forbidden"}), 403
    data = request.get_json(force=True)
    target_id = int(data.get("user_id"))
    heart = int(data.get("heart_rate", random.randint(60,120)))
    ts = dt.datetime.utcnow().isoformat()
    socketio.emit('hr_update', {'user_id': target_id, 'heart_rate': heart, 'timestamp': ts}, room=f"user_{target_id}")
    return jsonify({"status": "emitted", "user_id": target_id, "heart_rate": heart, "timestamp": ts})

# Socket.IO auth: client should send token when connecting
@socketio.on('connect')
def handle_connect():
    # no auth here; client should emit 'auth' immediately
    emit('connected', {'msg': 'connected - please authenticate'})

@socketio.on('auth')
def handle_auth(data):
    token = data.get('token')
    if not token:
        emit('error', {'msg': 'token required'})
        disconnect()
        return
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGO])
        uid = payload['sub']
        role = payload.get('role', 'user')
    except Exception as e:
        emit('error', {'msg': 'invalid token', 'details': str(e)})
        disconnect()
        return
    # store user's id in session and join a personal room
    join_room(f"user_{uid}")
    emit('authenticated', {'user_id': uid, 'role': role})

@socketio.on('join_user_room')
def on_join(data):
    # allow doctors to join patient's room for live updates (requires token-auth via 'auth' earlier)
    token = data.get('token')
    patient_id = data.get('user_id')
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGO])
        role = payload.get('role', 'user')
        if role not in ('doctor','admin') and payload['sub'] != int(patient_id):
            emit('error', {'msg': 'forbidden'})
            return
        join_room(f"user_{patient_id}")
        emit('joined', {'room': f"user_{patient_id}"})
    except Exception as e:
        emit('error', {'msg': 'invalid token', 'details': str(e)})

@app.route("/")
def root():
    return jsonify({"status": "running", "message": "Smart Health Tracker API with SocketIO"})


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    # When using SocketIO with eventlet/gevent, use socketio.run
    socketio.run(app, host="0.0.0.0", port=port, debug=True)