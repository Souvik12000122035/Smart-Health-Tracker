import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api, setToken } from '../services/api'

export default function Login({ setUser }) {
  const [email, setEmail] = useState('demo@example.com')
  const [password, setPassword] = useState('demo1234')
  const [name, setName] = useState('Demo User')
  const [mode, setMode] = useState('login')
  const [role, setRole] = useState('user')
  const [error, setError] = useState(null)
  const navigate = useNavigate()

  const submit = async (e) => {
    e.preventDefault()
    setError(null)
    try {
      const path = mode === 'login' ? '/login' : '/register'
      const body = mode === 'login' ? { email, password } : { name, email, password, role }
      const res = await api.post(path, body)
      setToken(res.data.token)
      const me = await api.get('/me')
      setUser(me.data)
      navigate('/')
    } catch (err) {
      setError(err.response?.data?.error || 'Something went wrong')
    }
  }

  return (
    <div style={{maxWidth: 420, margin: '24px auto'}}>
      <h2>{mode === 'login' ? 'Login' : 'Register'}</h2>
      <form onSubmit={submit} style={{display:'grid', gap:12}}>
        {mode === 'register' && (
          <label> Name
            <input value={name} onChange={e=>setName(e.target.value)} required/>
          </label>
        )}
        {mode === 'register' && (
          <label> Role
            <select value={role} onChange={e=>setRole(e.target.value)}>
              <option value="user">User (patient)</option>
              <option value="doctor">Doctor</option>
            </select>
          </label>
        )}
        <label> Email
          <input type="email" value={email} onChange={e=>setEmail(e.target.value)} required/>
        </label>
        <label> Password
          <input type="password" value={password} onChange={e=>setPassword(e.target.value)} required/>
        </label>
        <button type="submit">{mode === 'login' ? 'Login' : 'Create account'}</button>
      </form>
      <div style={{marginTop:12}}>
        <button onClick={()=>setMode(mode==='login'?'register':'login')}>
          Switch to {mode==='login'?'Register':'Login'}
        </button>
      </div>
      {error && <p style={{color:'red'}}>{error}</p>}
    </div>
  )
}