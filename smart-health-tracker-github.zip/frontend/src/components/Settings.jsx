import React, { useState } from 'react'
import { api } from '../services/api'

export default function Settings() {
  const [days, setDays] = useState(7)
  const [msg, setMsg] = useState(null)

  const simulate = async () => {
    const res = await api.post('/simulate', {days: Number(days)})
    setMsg(`Created ${res.data.created} synthetic records`)
  }

  return (
    <div style={{maxWidth: 420}}>
      <h2>Data Simulator</h2>
      <label>Days
        <input type="number" min="1" max="60" value={days} onChange={e=>setDays(e.target.value)} />
      </label>
      <div style={{marginTop:12}}>
        <button onClick={simulate}>Generate</button>
      </div>
      {msg && <p>{msg}</p>}
      <p style={{marginTop:16, fontSize:12, opacity:0.7}}>
        This simulates wearable data (steps, heart rate, calories, sleep). Replace this with real device integration later.
      </p>
    </div>
  )
}