import axios from 'axios'

export const api = axios.create({
  baseURL: '/api'
})

export function setToken(token) {
  localStorage.setItem('token', token)
  api.defaults.headers.common['Authorization'] = `Bearer ${token}`
}

export function clearToken() {
  localStorage.removeItem('token')
  delete api.defaults.headers.common['Authorization']
}

export function getToken() {
  const t = localStorage.getItem('token')
  if (t) setToken(t)
  return t
}