# Smart Health Tracker – Backend (Flask + SocketIO + SQLite)

## Quickstart
```bash
cd backend
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```
The API + Socket.IO runs on `http://localhost:5000`.

## Key Additions
- Roles: `user`, `doctor`, `admin`
- Doctor endpoints: `GET /api/users`, `GET /api/users/<id>/metrics`
- WebSocket (Socket.IO): authenticate via `auth` event and join rooms `user_<id>`
- Live HR events emitted as `hr_update`