import React, { useEffect, useState, useRef } from 'react'
import { api, getToken } from '../services/api'
import { io } from 'socket.io-client'

export default function DoctorDashboard({ user }) {
  const [patients, setPatients] = useState([])
  const [selected, setSelected] = useState(null)
  const [liveHR, setLiveHR] = useState(null)
  const socketRef = useRef(null)

  useEffect(() => {
    const init = async () => {
      try {
        const res = await api.get('/users')
        setPatients(res.data)
      } catch (e) {
        console.error(e)
      }
    }
    init()
  }, [])

  useEffect(() => {
    // connect socket and authenticate
    const token = getToken()
    if (!token) return
    const socket = io('/', { autoConnect: false })
    socket.connect()
    socket.on('connect', () => {
      socket.emit('auth', { token })
    })
    socket.on('authenticated', (d)=>{ console.log('socket auth', d) })
    socket.on('hr_update', (d)=>{
      // only update if the event belongs to currently selected patient
      if (selected && d.user_id === selected.id) setLiveHR(d)
    })
    socketRef.current = socket
    return () => {
      socket.disconnect()
    }
  }, [selected])

  const selectPatient = async (p) => {
    setSelected(p)
    setLiveHR(null)
    // join patient's room (server will validate token)
    try {
      const token = getToken()
      socketRef.current.emit('join_user_room', { token, user_id: p.id })
      // fetch recent metrics
      const res = await api.get(`/users/${p.id}/metrics`)
      // show latest HR if exists
      if (res.data && res.data.length) {
        setLiveHR({ user_id: p.id, heart_rate: res.data[0].heart_rate, timestamp: res.data[0].timestamp })
      }
    } catch (e) {
      console.error(e)
    }
  }

  const emitSim = async () => {
    if (!selected) return
    const hr = Math.floor(Math.random()*60)+60
    await api.post('/emit-simulate', { user_id: selected.id, heart_rate: hr })
  }

  return (
    <div style={{display:'flex', gap:16}}>
      <aside style={{width:280}}>
        <h3>Patients</h3>
        <ul>
          {patients.map(p=>(
            <li key={p.id} style={{cursor:'pointer', marginBottom:8}} onClick={()=>selectPatient(p)}>
              {p.name} <br/><small style={{opacity:0.7}}>{p.email}</small>
            </li>
          ))}
        </ul>
      </aside>
      <main style={{flex:1}}>
        <h2>Doctor View</h2>
        {selected ? (
          <div>
            <h3>{selected.name} — Live Heart Rate</h3>
            <div style={{fontSize:48, fontWeight:700}}>{liveHR ? `${liveHR.heart_rate} bpm` : 'No data yet'}</div>
            <div style={{marginTop:12}}>
              <button onClick={emitSim}>Simulate Live HR</button>
            </div>
          </div>
        ) : (
          <p>Select a patient to view live HR</p>
        )}
      </main>
    </div>
  )
}